import 'package:flutter/material.dart';
import 'package:abhijit_s_application41/presentation/documents_container_screen/documents_container_screen.dart';
import 'package:abhijit_s_application41/presentation/transaction_documents_screen/transaction_documents_screen.dart';
import 'package:abhijit_s_application41/presentation/transaction_documents_detail_page_screen/transaction_documents_detail_page_screen.dart';
import 'package:abhijit_s_application41/presentation/joining_documents_screen/joining_documents_screen.dart';
import 'package:abhijit_s_application41/presentation/team_documents_screen/team_documents_screen.dart';
import 'package:abhijit_s_application41/presentation/tax_documents_screen/tax_documents_screen.dart';
import 'package:abhijit_s_application41/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String documentsPage = '/documents_page';

  static const String documentsContainerScreen = '/documents_container_screen';

  static const String transactionDocumentsScreen =
      '/transaction_documents_screen';

  static const String transactionDocumentsDetailPageScreen =
      '/transaction_documents_detail_page_screen';

  static const String joiningDocumentsScreen = '/joining_documents_screen';

  static const String teamDocumentsScreen = '/team_documents_screen';

  static const String taxDocumentsScreen = '/tax_documents_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        documentsContainerScreen: DocumentsContainerScreen.builder,
        transactionDocumentsScreen: TransactionDocumentsScreen.builder,
        transactionDocumentsDetailPageScreen:
            TransactionDocumentsDetailPageScreen.builder,
        joiningDocumentsScreen: JoiningDocumentsScreen.builder,
        teamDocumentsScreen: TeamDocumentsScreen.builder,
        taxDocumentsScreen: TaxDocumentsScreen.builder,
        appNavigationScreen: AppNavigationScreen.builder,
        initialRoute: DocumentsContainerScreen.builder
      };
}
