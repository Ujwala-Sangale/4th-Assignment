import '../models/listofdocuments_item_model.dart';
import 'package:abhijit_s_application41/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ListofdocumentsItemWidget extends StatelessWidget {
  ListofdocumentsItemWidget(
    this.listofdocumentsItemModelObj, {
    Key? key,
    this.navigatetoDetails,
  }) : super(
          key: key,
        );

  ListofdocumentsItemModel listofdocumentsItemModelObj;

  VoidCallback? navigatetoDetails;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 16.h,
        vertical: 15.v,
      ),
      decoration: AppDecoration.fillWhiteA.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder10,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 177.h,
            child: Text(
              listofdocumentsItemModelObj.address!,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.titleSmall!.copyWith(
                height: 1.29,
              ),
            ),
          ),
          SizedBox(height: 3.v),
          Text(
            listofdocumentsItemModelObj.transactionId!,
            style: theme.textTheme.bodySmall,
          ),
          SizedBox(height: 18.v),
          Row(
            children: [
              SizedBox(
                width: 64.h,
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: "lbl_settled_on".tr,
                        style: theme.textTheme.bodyMedium,
                      ),
                      TextSpan(
                        text: "lbl_09_04_23".tr,
                        style: CustomTextStyles.bodyMediumBluegray90001,
                      ),
                    ],
                  ),
                  textAlign: TextAlign.left,
                ),
              ),
              CustomImageView(
                imagePath: ImageConstant.imgArrowLeft,
                height: 24.adaptSize,
                width: 24.adaptSize,
                margin: EdgeInsets.only(
                  left: 214.h,
                  top: 5.v,
                  bottom: 6.v,
                ),
                onTap: () {
                  navigatetoDetails!.call();
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}
