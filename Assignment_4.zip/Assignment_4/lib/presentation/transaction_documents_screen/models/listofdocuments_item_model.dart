import '../../../core/app_export.dart';

/// This class is used in the [listofdocuments_item_widget] screen.
class ListofdocumentsItemModel {
  ListofdocumentsItemModel({
    this.address,
    this.transactionId,
    this.id,
  }) {
    address = address ?? "12782, 150th Avenue South,\nNew York, CA. 56345";
    transactionId = transactionId ?? "Transaction Id #235678";
    id = id ?? "";
  }

  String? address;

  String? transactionId;

  String? id;
}
