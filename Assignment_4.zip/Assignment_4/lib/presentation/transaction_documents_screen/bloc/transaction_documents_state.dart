// ignore_for_file: must_be_immutable

part of 'transaction_documents_bloc.dart';

/// Represents the state of TransactionDocuments in the application.
class TransactionDocumentsState extends Equatable {
  TransactionDocumentsState({this.transactionDocumentsModelObj});

  TransactionDocumentsModel? transactionDocumentsModelObj;

  @override
  List<Object?> get props => [
        transactionDocumentsModelObj,
      ];
  TransactionDocumentsState copyWith(
      {TransactionDocumentsModel? transactionDocumentsModelObj}) {
    return TransactionDocumentsState(
      transactionDocumentsModelObj:
          transactionDocumentsModelObj ?? this.transactionDocumentsModelObj,
    );
  }
}
