import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/listofdocuments_item_model.dart';
import 'package:abhijit_s_application41/presentation/transaction_documents_screen/models/transaction_documents_model.dart';
part 'transaction_documents_event.dart';
part 'transaction_documents_state.dart';

/// A bloc that manages the state of a TransactionDocuments according to the event that is dispatched to it.
class TransactionDocumentsBloc
    extends Bloc<TransactionDocumentsEvent, TransactionDocumentsState> {
  TransactionDocumentsBloc(TransactionDocumentsState initialState)
      : super(initialState) {
    on<TransactionDocumentsInitialEvent>(_onInitialize);
  }

  _onInitialize(
    TransactionDocumentsInitialEvent event,
    Emitter<TransactionDocumentsState> emit,
  ) async {
    emit(state.copyWith(
        transactionDocumentsModelObj: state.transactionDocumentsModelObj
            ?.copyWith(
                listofdocumentsItemList: fillListofdocumentsItemList())));
  }

  List<ListofdocumentsItemModel> fillListofdocumentsItemList() {
    return [
      ListofdocumentsItemModel(
          address: "12782, 150th Avenue South,\nNew York, CA. 56345",
          transactionId: "Transaction Id #235678"),
      ListofdocumentsItemModel(
          address: "4858, Rosemont Avenue,\nMelbourne, Florida 32901",
          transactionId: "Transaction Id #235678"),
      ListofdocumentsItemModel(
          address: "12782, 150th Avenue South,\nNew York, CA. 56345",
          transactionId: "Transaction Id #235678")
    ];
  }
}
