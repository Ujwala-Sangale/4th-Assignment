import '../../../core/app_export.dart';

/// This class is used in the [joiningdocuments_item_widget] screen.
class JoiningdocumentsItemModel {
  JoiningdocumentsItemModel({
    this.fileName,
    this.fileSize,
    this.id,
  }) {
    fileName = fileName ?? "Cheque.pdf";
    fileSize = fileSize ?? "15 MB";
    id = id ?? "";
  }

  String? fileName;

  String? fileSize;

  String? id;
}
