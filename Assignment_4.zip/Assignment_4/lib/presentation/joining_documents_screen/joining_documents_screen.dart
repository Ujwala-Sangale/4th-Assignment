import '../joining_documents_screen/widgets/joiningdocuments_item_widget.dart';
import 'bloc/joining_documents_bloc.dart';
import 'models/joining_documents_model.dart';
import 'models/joiningdocuments_item_model.dart';
import 'package:abhijit_s_application41/core/app_export.dart';
import 'package:abhijit_s_application41/widgets/app_bar/appbar_leading_image.dart';
import 'package:abhijit_s_application41/widgets/app_bar/appbar_title.dart';
import 'package:abhijit_s_application41/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class JoiningDocumentsScreen extends StatelessWidget {
  const JoiningDocumentsScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<JoiningDocumentsBloc>(
        create: (context) => JoiningDocumentsBloc(JoiningDocumentsState(
            joiningDocumentsModelObj: JoiningDocumentsModel()))
          ..add(JoiningDocumentsInitialEvent()),
        child: JoiningDocumentsScreen());
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(context),
            body: Padding(
                padding: EdgeInsets.only(left: 20.h, top: 22.v, right: 20.h),
                child: BlocSelector<JoiningDocumentsBloc, JoiningDocumentsState,
                        JoiningDocumentsModel?>(
                    selector: (state) => state.joiningDocumentsModelObj,
                    builder: (context, joiningDocumentsModelObj) {
                      return ListView.separated(
                          physics: BouncingScrollPhysics(),
                          shrinkWrap: true,
                          separatorBuilder: (context, index) {
                            return Padding(
                                padding: EdgeInsets.symmetric(vertical: 11.0.v),
                                child: SizedBox(
                                    width: 335.h,
                                    child: Divider(
                                        height: 1.v,
                                        thickness: 1.v,
                                        color: appTheme.blueGray90001
                                            .withOpacity(0.05))));
                          },
                          itemCount: joiningDocumentsModelObj
                                  ?.joiningdocumentsItemList.length ??
                              0,
                          itemBuilder: (context, index) {
                            JoiningdocumentsItemModel model =
                                joiningDocumentsModelObj
                                        ?.joiningdocumentsItemList[index] ??
                                    JoiningdocumentsItemModel();
                            return JoiningdocumentsItemWidget(model);
                          });
                    }))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 36.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 12.h, top: 10.v, bottom: 10.v),
            onTap: () {
              onTapArrowLeft(context);
            }),
        centerTitle: true,
        title: AppbarTitle(text: "msg_joining_documents".tr),
        styleType: Style.bgFill);
  }

  /// Navigates to the previous screen.
  onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
