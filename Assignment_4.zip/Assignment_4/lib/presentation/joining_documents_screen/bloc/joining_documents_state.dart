// ignore_for_file: must_be_immutable

part of 'joining_documents_bloc.dart';

/// Represents the state of JoiningDocuments in the application.
class JoiningDocumentsState extends Equatable {
  JoiningDocumentsState({this.joiningDocumentsModelObj});

  JoiningDocumentsModel? joiningDocumentsModelObj;

  @override
  List<Object?> get props => [
        joiningDocumentsModelObj,
      ];
  JoiningDocumentsState copyWith(
      {JoiningDocumentsModel? joiningDocumentsModelObj}) {
    return JoiningDocumentsState(
      joiningDocumentsModelObj:
          joiningDocumentsModelObj ?? this.joiningDocumentsModelObj,
    );
  }
}
