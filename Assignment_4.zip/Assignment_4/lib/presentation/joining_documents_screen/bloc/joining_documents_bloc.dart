import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/joiningdocuments_item_model.dart';
import 'package:abhijit_s_application41/presentation/joining_documents_screen/models/joining_documents_model.dart';
part 'joining_documents_event.dart';
part 'joining_documents_state.dart';

/// A bloc that manages the state of a JoiningDocuments according to the event that is dispatched to it.
class JoiningDocumentsBloc
    extends Bloc<JoiningDocumentsEvent, JoiningDocumentsState> {
  JoiningDocumentsBloc(JoiningDocumentsState initialState)
      : super(initialState) {
    on<JoiningDocumentsInitialEvent>(_onInitialize);
  }

  _onInitialize(
    JoiningDocumentsInitialEvent event,
    Emitter<JoiningDocumentsState> emit,
  ) async {
    emit(state.copyWith(
        joiningDocumentsModelObj: state.joiningDocumentsModelObj?.copyWith(
            joiningdocumentsItemList: fillJoiningdocumentsItemList())));
  }

  List<JoiningdocumentsItemModel> fillJoiningdocumentsItemList() {
    return [
      JoiningdocumentsItemModel(fileName: "Cheque.pdf", fileSize: "15 MB"),
      JoiningdocumentsItemModel(
          fileName: "Settlement Document.pdf", fileSize: "15 MB"),
      JoiningdocumentsItemModel(fileName: "ICA Document.pdf", fileSize: "15 MB")
    ];
  }
}
