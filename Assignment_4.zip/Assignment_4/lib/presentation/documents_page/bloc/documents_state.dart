// ignore_for_file: must_be_immutable

part of 'documents_bloc.dart';

/// Represents the state of Documents in the application.
class DocumentsState extends Equatable {
  DocumentsState({this.documentsModelObj});

  DocumentsModel? documentsModelObj;

  @override
  List<Object?> get props => [
        documentsModelObj,
      ];
  DocumentsState copyWith({DocumentsModel? documentsModelObj}) {
    return DocumentsState(
      documentsModelObj: documentsModelObj ?? this.documentsModelObj,
    );
  }
}
