import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:abhijit_s_application41/presentation/documents_page/models/documents_model.dart';
part 'documents_event.dart';
part 'documents_state.dart';

/// A bloc that manages the state of a Documents according to the event that is dispatched to it.
class DocumentsBloc extends Bloc<DocumentsEvent, DocumentsState> {
  DocumentsBloc(DocumentsState initialState) : super(initialState) {
    on<DocumentsInitialEvent>(_onInitialize);
  }

  _onInitialize(
    DocumentsInitialEvent event,
    Emitter<DocumentsState> emit,
  ) async {}
}
