import 'bloc/documents_bloc.dart';
import 'models/documents_model.dart';
import 'package:abhijit_s_application41/core/app_export.dart';
import 'package:abhijit_s_application41/widgets/app_bar/appbar_title.dart';
import 'package:abhijit_s_application41/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class DocumentsPage extends StatelessWidget {
  const DocumentsPage({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<DocumentsBloc>(
        create: (context) =>
            DocumentsBloc(DocumentsState(documentsModelObj: DocumentsModel()))
              ..add(DocumentsInitialEvent()),
        child: DocumentsPage());
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<DocumentsBloc, DocumentsState>(
        builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              appBar: _buildAppBar(context),
              body: Container(
                  width: double.maxFinite,
                  padding:
                      EdgeInsets.symmetric(horizontal: 19.h, vertical: 20.v),
                  child: Column(children: [
                    _buildTransactionDocument(context,
                        text: "msg_joining_document".tr,
                        onTapTransactionDocument: () {
                      onTapJoiningDocument(context);
                    }, NvaigatetoTransition: () {
                      navigatetoDocument(context);
                    }),
                    SizedBox(height: 16.v),
                    Divider(),
                    SizedBox(height: 20.v),
                    _buildTransactionDocument(context,
                        text: "msg_transaction_document".tr,
                        NvaigatetoTransition: () {
                      NvaigatetoTransition(context);
                    }),
                    SizedBox(height: 16.v),
                    Divider(),
                    SizedBox(height: 20.v),
                    _buildTransactionDocument(context,
                        text: "lbl_team_documents".tr),
                    SizedBox(height: 16.v),
                    Divider(),
                    SizedBox(height: 20.v),
                    _buildTransactionDocument(context,
                        text: "lbl_tax_document".tr,
                        onTapTransactionDocument: () {
                      onTapFrame(context);
                    }),
                    SizedBox(height: 5.v)
                  ]))));
    });
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        centerTitle: true,
        title: AppbarTitle(text: "lbl_documents".tr),
        styleType: Style.bgFill);
  }

  /// Common widget
  Widget _buildTransactionDocument(
    BuildContext context, {
    required String text,
    Function? onTapTransactionDocument,
    Function? nvaigatetoTransition,
  }) {
    return GestureDetector(
        onTap: () {
          onTapTransactionDocument!.call();
        },
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Padding(
              padding: EdgeInsets.only(top: 1.v, bottom: 3.v),
              child: Text(text,
                  style: theme.textTheme.bodyLarge!
                      .copyWith(color: appTheme.blueGray900))),
          CustomImageView(
              imagePath: ImageConstant.imgArrowLeft,
              height: 24.v,
              width: 25.h,
              onTap: () {
                NvaigatetoTransition!.call();
              })
        ]));
  }

  /// Navigates to the joiningDocumentsScreen when the action is triggered.
  onTapJoiningDocument(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.joiningDocumentsScreen,
    );
  }

  /// Navigates to the transactionDocumentsScreen when the action is triggered.
  navigatetoDocument(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.transactionDocumentsScreen,
    );
  }

  /// Navigates to the transactionDocumentsScreen when the action is triggered.
  NvaigatetoTransition(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.transactionDocumentsScreen,
    );
  }

  /// Navigates to the taxDocumentsScreen when the action is triggered.
  onTapFrame(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.taxDocumentsScreen,
    );
  }
}
