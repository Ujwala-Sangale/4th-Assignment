import '../tax_documents_screen/widgets/fileviewer1_item_widget.dart';
import 'bloc/tax_documents_bloc.dart';
import 'models/fileviewer1_item_model.dart';
import 'models/tax_documents_model.dart';
import 'package:abhijit_s_application41/core/app_export.dart';
import 'package:abhijit_s_application41/widgets/app_bar/appbar_leading_image.dart';
import 'package:abhijit_s_application41/widgets/app_bar/appbar_title.dart';
import 'package:abhijit_s_application41/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class TaxDocumentsScreen extends StatelessWidget {
  const TaxDocumentsScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<TaxDocumentsBloc>(
        create: (context) => TaxDocumentsBloc(
            TaxDocumentsState(taxDocumentsModelObj: TaxDocumentsModel()))
          ..add(TaxDocumentsInitialEvent()),
        child: TaxDocumentsScreen());
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(context),
            body: Padding(
                padding: EdgeInsets.only(left: 20.h, top: 22.v, right: 20.h),
                child: BlocSelector<TaxDocumentsBloc, TaxDocumentsState,
                        TaxDocumentsModel?>(
                    selector: (state) => state.taxDocumentsModelObj,
                    builder: (context, taxDocumentsModelObj) {
                      return ListView.separated(
                          physics: BouncingScrollPhysics(),
                          shrinkWrap: true,
                          separatorBuilder: (context, index) {
                            return Padding(
                                padding: EdgeInsets.symmetric(vertical: 11.0.v),
                                child: SizedBox(
                                    width: 335.h,
                                    child: Divider(
                                        height: 1.v,
                                        thickness: 1.v,
                                        color: appTheme.blueGray90001
                                            .withOpacity(0.05))));
                          },
                          itemCount: taxDocumentsModelObj
                                  ?.fileviewer1ItemList.length ??
                              0,
                          itemBuilder: (context, index) {
                            Fileviewer1ItemModel model = taxDocumentsModelObj
                                    ?.fileviewer1ItemList[index] ??
                                Fileviewer1ItemModel();
                            return Fileviewer1ItemWidget(model);
                          });
                    }))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 36.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 12.h, top: 10.v, bottom: 10.v),
            onTap: () {
              onTapArrowLeft(context);
            }),
        centerTitle: true,
        title: AppbarTitle(text: "lbl_tax_documents".tr),
        styleType: Style.bgFill);
  }

  /// Navigates to the previous screen.
  onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
