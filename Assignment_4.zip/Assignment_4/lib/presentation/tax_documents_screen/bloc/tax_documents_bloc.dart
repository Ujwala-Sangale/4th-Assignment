import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/fileviewer1_item_model.dart';
import 'package:abhijit_s_application41/presentation/tax_documents_screen/models/tax_documents_model.dart';
part 'tax_documents_event.dart';
part 'tax_documents_state.dart';

/// A bloc that manages the state of a TaxDocuments according to the event that is dispatched to it.
class TaxDocumentsBloc extends Bloc<TaxDocumentsEvent, TaxDocumentsState> {
  TaxDocumentsBloc(TaxDocumentsState initialState) : super(initialState) {
    on<TaxDocumentsInitialEvent>(_onInitialize);
  }

  _onInitialize(
    TaxDocumentsInitialEvent event,
    Emitter<TaxDocumentsState> emit,
  ) async {
    emit(state.copyWith(
        taxDocumentsModelObj: state.taxDocumentsModelObj
            ?.copyWith(fileviewer1ItemList: fillFileviewer1ItemList())));
  }

  List<Fileviewer1ItemModel> fillFileviewer1ItemList() {
    return [
      Fileviewer1ItemModel(fileName: "1099.pdf", fileSize: "15 MB"),
      Fileviewer1ItemModel(fileName: "w9.pdf", fileSize: "15 MB"),
      Fileviewer1ItemModel(fileName: "Tax statement.pdf", fileSize: "15 MB")
    ];
  }
}
