// ignore_for_file: must_be_immutable

part of 'tax_documents_bloc.dart';

/// Represents the state of TaxDocuments in the application.
class TaxDocumentsState extends Equatable {
  TaxDocumentsState({this.taxDocumentsModelObj});

  TaxDocumentsModel? taxDocumentsModelObj;

  @override
  List<Object?> get props => [
        taxDocumentsModelObj,
      ];
  TaxDocumentsState copyWith({TaxDocumentsModel? taxDocumentsModelObj}) {
    return TaxDocumentsState(
      taxDocumentsModelObj: taxDocumentsModelObj ?? this.taxDocumentsModelObj,
    );
  }
}
