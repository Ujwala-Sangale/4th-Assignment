import '../../../core/app_export.dart';

/// This class is used in the [fileviewer1_item_widget] screen.
class Fileviewer1ItemModel {
  Fileviewer1ItemModel({
    this.fileName,
    this.fileSize,
    this.id,
  }) {
    fileName = fileName ?? "1099.pdf";
    fileSize = fileSize ?? "15 MB";
    id = id ?? "";
  }

  String? fileName;

  String? fileSize;

  String? id;
}
