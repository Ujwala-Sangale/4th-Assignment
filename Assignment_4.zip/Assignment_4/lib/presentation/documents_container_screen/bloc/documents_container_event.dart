// ignore_for_file: must_be_immutable

part of 'documents_container_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///DocumentsContainer widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class DocumentsContainerEvent extends Equatable {}

/// Event that is dispatched when the DocumentsContainer widget is first created.
class DocumentsContainerInitialEvent extends DocumentsContainerEvent {
  @override
  List<Object?> get props => [];
}
