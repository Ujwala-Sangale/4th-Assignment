import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:abhijit_s_application41/presentation/documents_container_screen/models/documents_container_model.dart';
part 'documents_container_event.dart';
part 'documents_container_state.dart';

/// A bloc that manages the state of a DocumentsContainer according to the event that is dispatched to it.
class DocumentsContainerBloc
    extends Bloc<DocumentsContainerEvent, DocumentsContainerState> {
  DocumentsContainerBloc(DocumentsContainerState initialState)
      : super(initialState) {
    on<DocumentsContainerInitialEvent>(_onInitialize);
  }

  _onInitialize(
    DocumentsContainerInitialEvent event,
    Emitter<DocumentsContainerState> emit,
  ) async {
    Future.delayed(const Duration(milliseconds: 3000), () {
      NavigatorService.popAndPushNamed(
        AppRoutes.transactionDocumentsScreen,
      );
    });
  }
}
