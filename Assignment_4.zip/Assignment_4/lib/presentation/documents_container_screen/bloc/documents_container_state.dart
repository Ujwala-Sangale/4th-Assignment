// ignore_for_file: must_be_immutable

part of 'documents_container_bloc.dart';

/// Represents the state of DocumentsContainer in the application.
class DocumentsContainerState extends Equatable {
  DocumentsContainerState({this.documentsContainerModelObj});

  DocumentsContainerModel? documentsContainerModelObj;

  @override
  List<Object?> get props => [
        documentsContainerModelObj,
      ];
  DocumentsContainerState copyWith(
      {DocumentsContainerModel? documentsContainerModelObj}) {
    return DocumentsContainerState(
      documentsContainerModelObj:
          documentsContainerModelObj ?? this.documentsContainerModelObj,
    );
  }
}
