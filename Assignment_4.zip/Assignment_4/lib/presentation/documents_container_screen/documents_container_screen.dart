import 'bloc/documents_container_bloc.dart';
import 'models/documents_container_model.dart';
import 'package:abhijit_s_application41/core/app_export.dart';
import 'package:abhijit_s_application41/presentation/documents_page/documents_page.dart';
import 'package:abhijit_s_application41/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class DocumentsContainerScreen extends StatelessWidget {
  DocumentsContainerScreen({Key? key}) : super(key: key);

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<DocumentsContainerBloc>(
        create: (context) => DocumentsContainerBloc(DocumentsContainerState(
            documentsContainerModelObj: DocumentsContainerModel()))
          ..add(DocumentsContainerInitialEvent()),
        child: DocumentsContainerScreen());
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<DocumentsContainerBloc, DocumentsContainerState>(
        builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              body: Navigator(
                  key: navigatorKey,
                  initialRoute: AppRoutes.documentsPage,
                  onGenerateRoute: (routeSetting) => PageRouteBuilder(
                      pageBuilder: (ctx, ani, ani1) =>
                          getCurrentPage(context, routeSetting.name!),
                      transitionDuration: Duration(seconds: 0))),
              bottomNavigationBar: _buildBottomBar(context)));
    });
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(onChanged: (BottomBarEnum type) {
      Navigator.pushNamed(navigatorKey.currentContext!, getCurrentRoute(type));
    });
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Documents:
        return AppRoutes.documentsPage;
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(
    BuildContext context,
    String currentRoute,
  ) {
    switch (currentRoute) {
      case AppRoutes.documentsPage:
        return DocumentsPage();
      default:
        return DefaultWidget();
    }
  }
}
