// ignore_for_file: must_be_immutable

part of 'team_documents_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///TeamDocuments widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class TeamDocumentsEvent extends Equatable {}

/// Event that is dispatched when the TeamDocuments widget is first created.
class TeamDocumentsInitialEvent extends TeamDocumentsEvent {
  @override
  List<Object?> get props => [];
}
