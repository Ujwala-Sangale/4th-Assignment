// ignore_for_file: must_be_immutable

part of 'team_documents_bloc.dart';

/// Represents the state of TeamDocuments in the application.
class TeamDocumentsState extends Equatable {
  TeamDocumentsState({this.teamDocumentsModelObj});

  TeamDocumentsModel? teamDocumentsModelObj;

  @override
  List<Object?> get props => [
        teamDocumentsModelObj,
      ];
  TeamDocumentsState copyWith({TeamDocumentsModel? teamDocumentsModelObj}) {
    return TeamDocumentsState(
      teamDocumentsModelObj:
          teamDocumentsModelObj ?? this.teamDocumentsModelObj,
    );
  }
}
