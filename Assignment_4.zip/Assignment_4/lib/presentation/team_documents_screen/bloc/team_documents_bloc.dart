import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/fileviewer_item_model.dart';
import 'package:abhijit_s_application41/presentation/team_documents_screen/models/team_documents_model.dart';
part 'team_documents_event.dart';
part 'team_documents_state.dart';

/// A bloc that manages the state of a TeamDocuments according to the event that is dispatched to it.
class TeamDocumentsBloc extends Bloc<TeamDocumentsEvent, TeamDocumentsState> {
  TeamDocumentsBloc(TeamDocumentsState initialState) : super(initialState) {
    on<TeamDocumentsInitialEvent>(_onInitialize);
  }

  _onInitialize(
    TeamDocumentsInitialEvent event,
    Emitter<TeamDocumentsState> emit,
  ) async {
    emit(state.copyWith(
        teamDocumentsModelObj: state.teamDocumentsModelObj
            ?.copyWith(fileviewerItemList: fillFileviewerItemList())));
  }

  List<FileviewerItemModel> fillFileviewerItemList() {
    return [
      FileviewerItemModel(fileName: "Cheque.pdf", fileSize: "15 MB"),
      FileviewerItemModel(
          fileName: "Settlement Document.pdf", fileSize: "15 MB"),
      FileviewerItemModel(fileName: "ICA Document.pdf", fileSize: "15 MB")
    ];
  }
}
