import '../team_documents_screen/widgets/fileviewer_item_widget.dart';
import 'bloc/team_documents_bloc.dart';
import 'models/fileviewer_item_model.dart';
import 'models/team_documents_model.dart';
import 'package:abhijit_s_application41/core/app_export.dart';
import 'package:abhijit_s_application41/widgets/app_bar/appbar_leading_image.dart';
import 'package:abhijit_s_application41/widgets/app_bar/appbar_title.dart';
import 'package:abhijit_s_application41/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class TeamDocumentsScreen extends StatelessWidget {
  const TeamDocumentsScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<TeamDocumentsBloc>(
        create: (context) => TeamDocumentsBloc(
            TeamDocumentsState(teamDocumentsModelObj: TeamDocumentsModel()))
          ..add(TeamDocumentsInitialEvent()),
        child: TeamDocumentsScreen());
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(context),
            body: Padding(
                padding: EdgeInsets.only(left: 20.h, top: 22.v, right: 20.h),
                child: BlocSelector<TeamDocumentsBloc, TeamDocumentsState,
                        TeamDocumentsModel?>(
                    selector: (state) => state.teamDocumentsModelObj,
                    builder: (context, teamDocumentsModelObj) {
                      return ListView.separated(
                          physics: BouncingScrollPhysics(),
                          shrinkWrap: true,
                          separatorBuilder: (context, index) {
                            return Padding(
                                padding: EdgeInsets.symmetric(vertical: 11.0.v),
                                child: SizedBox(
                                    width: 335.h,
                                    child: Divider(
                                        height: 1.v,
                                        thickness: 1.v,
                                        color: appTheme.blueGray90001
                                            .withOpacity(0.05))));
                          },
                          itemCount: teamDocumentsModelObj
                                  ?.fileviewerItemList.length ??
                              0,
                          itemBuilder: (context, index) {
                            FileviewerItemModel model = teamDocumentsModelObj
                                    ?.fileviewerItemList[index] ??
                                FileviewerItemModel();
                            return FileviewerItemWidget(model);
                          });
                    }))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 36.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 12.h, top: 10.v, bottom: 10.v),
            onTap: () {
              onTapArrowLeft(context);
            }),
        centerTitle: true,
        title: AppbarTitle(text: "lbl_team_documents".tr),
        styleType: Style.bgFill);
  }

  /// Navigates to the previous screen.
  onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
