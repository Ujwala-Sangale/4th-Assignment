import '../../../core/app_export.dart';

/// This class is used in the [fileviewer_item_widget] screen.
class FileviewerItemModel {
  FileviewerItemModel({
    this.fileName,
    this.fileSize,
    this.id,
  }) {
    fileName = fileName ?? "Cheque.pdf";
    fileSize = fileSize ?? "15 MB";
    id = id ?? "";
  }

  String? fileName;

  String? fileSize;

  String? id;
}
