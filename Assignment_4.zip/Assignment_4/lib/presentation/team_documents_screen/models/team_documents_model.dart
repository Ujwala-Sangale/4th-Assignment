// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';
import '../../../core/app_export.dart';
import 'fileviewer_item_model.dart';

/// This class defines the variables used in the [team_documents_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class TeamDocumentsModel extends Equatable {
  TeamDocumentsModel({this.fileviewerItemList = const []}) {}

  List<FileviewerItemModel> fileviewerItemList;

  TeamDocumentsModel copyWith({List<FileviewerItemModel>? fileviewerItemList}) {
    return TeamDocumentsModel(
      fileviewerItemList: fileviewerItemList ?? this.fileviewerItemList,
    );
  }

  @override
  List<Object?> get props => [fileviewerItemList];
}
