// ignore_for_file: must_be_immutable

part of 'transaction_documents_detail_page_bloc.dart';

/// Represents the state of TransactionDocumentsDetailPage in the application.
class TransactionDocumentsDetailPageState extends Equatable {
  TransactionDocumentsDetailPageState(
      {this.transactionDocumentsDetailPageModelObj});

  TransactionDocumentsDetailPageModel? transactionDocumentsDetailPageModelObj;

  @override
  List<Object?> get props => [
        transactionDocumentsDetailPageModelObj,
      ];
  TransactionDocumentsDetailPageState copyWith(
      {TransactionDocumentsDetailPageModel?
          transactionDocumentsDetailPageModelObj}) {
    return TransactionDocumentsDetailPageState(
      transactionDocumentsDetailPageModelObj:
          transactionDocumentsDetailPageModelObj ??
              this.transactionDocumentsDetailPageModelObj,
    );
  }
}
