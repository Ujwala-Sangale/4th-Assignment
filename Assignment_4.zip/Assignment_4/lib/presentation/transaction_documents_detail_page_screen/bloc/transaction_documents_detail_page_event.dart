// ignore_for_file: must_be_immutable

part of 'transaction_documents_detail_page_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///TransactionDocumentsDetailPage widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class TransactionDocumentsDetailPageEvent extends Equatable {}

/// Event that is dispatched when the TransactionDocumentsDetailPage widget is first created.
class TransactionDocumentsDetailPageInitialEvent
    extends TransactionDocumentsDetailPageEvent {
  @override
  List<Object?> get props => [];
}
