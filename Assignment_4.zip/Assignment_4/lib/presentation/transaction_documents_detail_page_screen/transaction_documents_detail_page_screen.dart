import 'bloc/transaction_documents_detail_page_bloc.dart';
import 'models/transaction_documents_detail_page_model.dart';
import 'package:abhijit_s_application41/core/app_export.dart';
import 'package:abhijit_s_application41/widgets/app_bar/appbar_leading_image.dart';
import 'package:abhijit_s_application41/widgets/app_bar/appbar_title.dart';
import 'package:abhijit_s_application41/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class TransactionDocumentsDetailPageScreen extends StatelessWidget {
  const TransactionDocumentsDetailPageScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<TransactionDocumentsDetailPageBloc>(
        create: (context) => TransactionDocumentsDetailPageBloc(
            TransactionDocumentsDetailPageState(
                transactionDocumentsDetailPageModelObj:
                    TransactionDocumentsDetailPageModel()))
          ..add(TransactionDocumentsDetailPageInitialEvent()),
        child: TransactionDocumentsDetailPageScreen());
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<TransactionDocumentsDetailPageBloc,
        TransactionDocumentsDetailPageState>(builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              appBar: _buildAppBar(context),
              body: Container(
                  width: double.maxFinite,
                  padding:
                      EdgeInsets.symmetric(horizontal: 19.h, vertical: 21.v),
                  child: Column(children: [
                    _buildEmailAddress(context),
                    SizedBox(height: 21.v),
                    _buildEmailAddress(context),
                    SizedBox(height: 21.v),
                    Align(
                        alignment: Alignment.centerLeft,
                        child: Text("lbl_document_name".tr,
                            style: CustomTextStyles.bodySmallGray500)),
                    SizedBox(height: 9.v),
                    _buildFrame(context,
                        dynamicText: "msg_license_document_pdf".tr,
                        onTapFrame: () {
                      navigatetoDocument(context);
                    }),
                    SizedBox(height: 16.v),
                    _buildFrame(context,
                        dynamicText: "msg_license_document_pdf".tr),
                    SizedBox(height: 16.v),
                    _buildFrame(context,
                        dynamicText: "msg_license_document_pdf".tr),
                    SizedBox(height: 5.v)
                  ]))));
    });
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 36.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 12.h, top: 10.v, bottom: 10.v),
            onTap: () {
              onTapArrowLeft(context);
            }),
        centerTitle: true,
        title: AppbarTitle(text: "msg_transaction_document".tr),
        styleType: Style.bgFill);
  }

  /// Common widget
  Widget _buildEmailAddress(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text("lbl_transaction_id".tr,
          style: CustomTextStyles.bodySmallBluegray400),
      SizedBox(height: 7.v),
      Text("lbl_235678".tr, style: theme.textTheme.bodyLarge),
      SizedBox(height: 18.v),
      Divider(color: appTheme.gray300)
    ]);
  }

  /// Common widget
  Widget _buildFrame(
    BuildContext context, {
    required String dynamicText,
    Function? onTapFrame,
  }) {
    return GestureDetector(
        onTap: () {
          onTapFrame!.call();
        },
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Padding(
              padding: EdgeInsets.symmetric(vertical: 2.v),
              child: Text(dynamicText,
                  style: theme.textTheme.bodyLarge!
                      .copyWith(color: appTheme.blueGray900))),
          CustomImageView(
              imagePath: ImageConstant.imgEye,
              height: 24.adaptSize,
              width: 24.adaptSize)
        ]));
  }

  /// Navigates to the previous screen.
  onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }

  /// Navigates to the taxDocumentsScreen when the action is triggered.
  navigatetoDocument(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.taxDocumentsScreen,
    );
  }
}
